const STORAGE_KEY = "studypilot-tasks-v1";
let tasks = loadTasks();
let totalFocusMinutes = Number(localStorage.getItem("studypilot-focus-minutes") || 0);
let selectedMinutes = 25;
let secondsLeft = selectedMinutes * 60;
let timerId = null;
let timerRunning = false;
let showAllTasks = false;
let toastId;

const $ = (selector) => document.querySelector(selector);
const taskForm = $("#task-form");
const taskInput = $("#task-input");
const taskList = $("#task-list");
const emptyState = $("#empty-state");

function loadTasks() {
  try {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    return Array.isArray(stored) ? stored : [];
  } catch { return []; }
}
function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
  localStorage.setItem("studypilot-focus-minutes", String(totalFocusMinutes));
  renderTasks();
  renderStats();
}
function toast(message) {
  const el = $("#toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toastId);
  toastId = setTimeout(() => el.classList.remove("show"), 2600);
}
function renderTasks() {
  taskList.innerHTML = "";
  const visibleTasks = showAllTasks ? tasks : tasks.slice(0, 5);
  emptyState.style.display = tasks.length ? "none" : "block";
  visibleTasks.forEach(task => {
    const row = document.createElement("div");
    row.className = `task-row${task.done ? " done" : ""}`;
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.className = "task-check";
    checkbox.checked = task.done;
    checkbox.setAttribute("aria-label", `Mark ${task.title} as ${task.done ? "not complete" : "complete"}`);
    checkbox.addEventListener("change", () => {
      task.done = checkbox.checked;
      save();
      if (task.done) toast("Task completed. Nice work! ✨");
    });
    const title = document.createElement("span");
    title.className = "task-title";
    title.textContent = task.title;
    const remove = document.createElement("button");
    remove.className = "task-delete";
    remove.type = "button";
    remove.textContent = "×";
    remove.setAttribute("aria-label", `Delete ${task.title}`);
    remove.addEventListener("click", () => {
      tasks = tasks.filter(item => item.id !== task.id);
      save();
      toast("Task removed.");
    });
    row.append(checkbox, title, remove);
    taskList.appendChild(row);
  });
  $("#show-all").textContent = showAllTasks ? "Show less" : "View all";
  $("#show-all").style.visibility = tasks.length > 5 || showAllTasks ? "visible" : "hidden";
}
function renderStats() {
  const completed = tasks.filter(task => task.done).length;
  const progress = tasks.length ? Math.round(completed / tasks.length * 100) : 0;
  $("#completed-count").textContent = completed;
  $("#focus-minutes").textContent = totalFocusMinutes;
  $("#progress-percent").textContent = `${progress}%`;
  $("#progress-bar").style.width = `${progress}%`;
}
function addTask(title) {
  const clean = title.trim();
  if (!clean) return;
  tasks.unshift({ id: `${Date.now()}-${Math.random().toString(16).slice(2)}`, title: clean, done: false });
  taskInput.value = "";
  save();
  toast("Task added to your plan.");
}
taskForm.addEventListener("submit", event => {
  event.preventDefault();
  addTask(taskInput.value);
});
$("#show-all").addEventListener("click", () => {
  showAllTasks = !showAllTasks;
  renderTasks();
});
function formatTime(totalSeconds) {
  const minutes = Math.floor(totalSeconds / 60).toString().padStart(2, "0");
  const seconds = (totalSeconds % 60).toString().padStart(2, "0");
  return `${minutes}:${seconds}`;
}
function renderTimer() {
  $("#timer-display").textContent = formatTime(secondsLeft);
  const elapsed = selectedMinutes * 60 - secondsLeft;
  const degrees = Math.min(360, Math.max(0, elapsed / (selectedMinutes * 60) * 360));
  $(".timer-ring").style.background = `conic-gradient(var(--purple) ${degrees}deg, #eeecfa ${degrees}deg)`;
}
function stopTimer() {
  clearInterval(timerId);
  timerId = null;
  timerRunning = false;
  $("#timer-toggle").textContent = "Start timer";
}
function startTimer() {
  if (timerRunning) {
    stopTimer();
    $("#timer-toggle").textContent = "Resume timer";
    return;
  }
  timerRunning = true;
  $("#timer-toggle").textContent = "Pause timer";
  timerId = setInterval(() => {
    secondsLeft -= 1;
    renderTimer();
    if (secondsLeft <= 0) {
      stopTimer();
      totalFocusMinutes += selectedMinutes;
      save();
      toast("Focus session complete! Take a short break. 🎉");
      $("#timer-toggle").textContent = "Start again";
      if ("Notification" in window && Notification.permission === "granted") {
        new Notification("StudyPilot", { body: "Your focus session is complete. Great job!" });
      }
    }
  }, 1000);
}
$("#timer-toggle").addEventListener("click", () => {
  if (secondsLeft <= 0) {
    secondsLeft = selectedMinutes * 60;
    renderTimer();
  }
  startTimer();
});
$("#timer-reset").addEventListener("click", () => {
  stopTimer();
  secondsLeft = selectedMinutes * 60;
  renderTimer();
  toast("Timer reset.");
});
document.querySelectorAll(".preset").forEach(button => {
  button.addEventListener("click", () => {
    stopTimer();
    selectedMinutes = Number(button.dataset.minutes);
    secondsLeft = selectedMinutes * 60;
    document.querySelectorAll(".preset").forEach(item => item.classList.toggle("active", item === button));
    renderTimer();
    $("#timer-toggle").textContent = "Start timer";
  });
});
$("#start-focus").addEventListener("click", () => {
  $("#focus-section").scrollIntoView({ behavior: "smooth", block: "center" });
  if (!timerRunning) startTimer();
});
document.querySelectorAll(".nav-item").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".nav-item").forEach(item => item.classList.toggle("active", item === button));
    const view = button.dataset.view;
    const target = view === "focus" ? $("#focus-section") : view === "tasks" ? $("#task-section") : $(".hero-card");
    target.scrollIntoView({ behavior: "smooth", block: "center" });
  });
});
$("#voice-btn").addEventListener("click", () => {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    toast("Voice input is not supported in this browser. Type your task instead.");
    return;
  }
  const recognition = new SpeechRecognition();
  recognition.lang = "en-IN";
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  $("#voice-btn").textContent = "🎙 Listening…";
  recognition.onresult = event => {
    const spokenText = event.results[0][0].transcript;
    addTask(spokenText);
  };
  recognition.onerror = () => toast("Couldn't hear that clearly. Please try again or type your task.");
  recognition.onend = () => { $("#voice-btn").textContent = "🎙 Try voice input"; };
  recognition.start();
});
const now = new Date();
$("#today-label").textContent = now.toLocaleDateString("en-IN", { weekday: "long", month: "long", day: "numeric" }).toUpperCase();
const hour = now.getHours();
$("#greeting").textContent = hour < 12 ? "Good morning. Let's focus." : hour < 17 ? "Let's make today count." : "A little progress goes a long way.";
renderTasks();
renderStats();
renderTimer();
